https://learn.microsoft.com/en-us/azure/cosmos-db/nosql/manage-with-terraform

