https://learn.microsoft.com/en-us/azure/mysql/flexible-server/quickstart-create-terraform?tabs=azure-cli

Verify the results
===================

az mysql flexible-server db show \
    --resource-group <resource_group_name> \
    --server-name <azurerm_mysql_flexible_server> \
    --database-name <mysql_flexible_server_database_name>

az mysql flexible-server db show \
    --resource-group rg-internal-coral \
    --server-name mysqlfs-oxtljjgs \
    --database-name mysqlfsdb_oxtljjgs    