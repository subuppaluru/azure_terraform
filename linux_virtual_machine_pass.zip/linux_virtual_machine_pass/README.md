https://learn.microsoft.com/en-us/azure/virtual-machines/linux/quick-create-terraform



virtual machine steps
======================

Create a virtual network
Create a subnet
Create a public IP address
Create a network security group and SSH inbound rule
Create a virtual network interface card
Connect the network security group to the network interface
Create a storage account for boot diagnostics
Create SSH key
Create a virtual machine
Use SSH to connect to virtual machine

terraform commands
==================

terraform init

terraform plan -out main_pass.tfplan

terraform apply main_pass.tfplan

terraform plan -destroy -out main.destroy.tfplan

terraform apply main.destroy.tfplan

Verify the results
===================

terraform output public_ip_address

ssh -i id_rsa azureuser@<public_ip_address>

ssh -i id_rsa azureuser@52.188.127.22