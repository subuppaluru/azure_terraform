https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine



virtual machine steps
======================

Create a virtual network
Create a subnet
Create a public IP address
Create a network security group and SSH inbound rule
Create a virtual network interface card
Connect the network security group to the network interface
Create a storage account for boot diagnostics
Create SSH key
Create a virtual machine
Use SSH to connect to virtual machine

terraform commands
==================

terraform init

terraform plan -out main.tfplan

terraform apply main.tfplan

terraform plan -destroy -out main.destroy.tfplan

terraform apply main.destroy.tfplan

Verify the results
===================

terraform output resource_group_name

