https://learn.microsoft.com/en-us/azure/developer/terraform/deploy-postgresql-flexible-server-database?tabs=azure-cli


Verify the results
==================

az postgres flexible-server db show --resource-group <resource_group_name> --server-name <server_name> --database-name <database_name>

